# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import transport_management_type
from . import transport_management_dock
from . import transport_management_inventory
from . import transport_management_transfers